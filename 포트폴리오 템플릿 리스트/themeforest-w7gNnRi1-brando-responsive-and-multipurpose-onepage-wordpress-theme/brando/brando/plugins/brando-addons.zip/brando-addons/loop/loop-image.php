<?php
/**
 * displaying featured image for blog
 *
 * @package Brando
 */
?>
<?php
global $brando_srcset;

echo '<div class="blog-image"><a href="'.get_permalink().'">';
    if ( has_post_thumbnail() ) {
        echo get_the_post_thumbnail( get_the_ID(), $brando_srcset );
    }
echo '</a></div>';

?>