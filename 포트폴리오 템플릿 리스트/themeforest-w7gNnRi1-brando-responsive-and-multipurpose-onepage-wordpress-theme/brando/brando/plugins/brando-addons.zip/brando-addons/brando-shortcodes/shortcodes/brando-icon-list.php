<?php
/**
 * Shortcode For Icon List
 *
 * @package Brando
 */
?>
<?php
/*-----------------------------------------------------------------------------------*/
/* Icon List */
/*-----------------------------------------------------------------------------------*/
add_shortcode('brando_font_class_list','brando_font_class_list_shortcode');
if ( ! function_exists( 'brando_font_class_list_shortcode' ) ) {
	function brando_font_class_list_shortcode( $atts, $content = null ) {
		extract( shortcode_atts( array(
	        	'id' => '',
	        	'class' => '',
	        	'brando_font_icon_class_type' => '',
	    ), $atts ) );
		
		$output = '';
		$id = ( $id ) ? ' id="'.$id.'"' : '';
		$class = ( $class ) ? ' '.$class : '';

		switch ($brando_font_icon_class_type) 
		{
			case 'brando_font_awesome_icons':
				$output .= '<div'.$id.' class="fa-examples'.$class.'">';
					$brando_fa_icon_solid  = brando_fontawesome_solid();
				    $brando_fa_icon_regular = brando_fontawesome_reg();
				    $brando_fa_icon_brand  = brando_fontawesome_brand();
				    $small_font_class = '';
					foreach ($brando_fa_icon_solid as $key => $icon) {
						$small_font_class = (strlen($icon) >= 35) ? ' icon-list-small-font' : '';
						$output .= '<div class="col-md-4 col-sm-6 col-lg-4'.$small_font_class.'">';
				        	$output .= '<i class="fas '.$icon.'"></i>';
				            $output .= 'fas '.$icon;
				        $output .= '</div>';	
					}
					foreach ($brando_fa_icon_regular as $key => $icon) {
						$small_font_class = (strlen($icon) >= 35) ? ' icon-list-small-font' : '';
						$output .= '<div class="col-md-4 col-sm-6 col-lg-4'.$small_font_class.'">';
				        	$output .= '<i class="far '.$icon.'"></i>';
				            $output .= 'far '.$icon;
				        $output .= '</div>';	
					}
					foreach ($brando_fa_icon_brand as $key => $icon) {
						$small_font_class = (strlen($icon) >= 35) ? ' icon-list-small-font' : '';
						$output .= '<div class="col-md-4 col-sm-6 col-lg-4'.$small_font_class.'">';
				        	$output .= '<i class="fab '.$icon.'"></i>';
				            $output .= 'fab '.$icon;
				        $output .= '</div>';	
					}
			    $output .= '</div>';
			break;

			case 'brando_et_line_icons':
				$output .= '<div'.$id.' class="'.$class.'">';
					$brando_icons = brando_icons();
					foreach ($brando_icons as $key => $icon) 
					{
						$output .= '<div class="glyphs">';
							$output .= '<span class="box1">';
				                $output .= '<span class="'.$icon.'" aria-hidden="true"></span>';
				                $output .= ' '.$icon;
			                $output .= '</span>';
		               $output .= '</div>';
		            }
		        $output .= '</div>';

			break;
		}
	    return $output;
	}
}