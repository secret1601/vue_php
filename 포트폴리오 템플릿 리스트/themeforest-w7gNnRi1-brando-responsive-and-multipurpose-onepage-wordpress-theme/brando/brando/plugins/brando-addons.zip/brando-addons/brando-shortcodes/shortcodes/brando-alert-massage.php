<?php
/**
 * Shortcode For Alert Message
 *
 * @package Brando
 */
?>
<?php
/*-----------------------------------------------------------------------------------*/
/* Alert Message */
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists( 'brando_alert_massage_shortcode' ) ) {
	function brando_alert_massage_shortcode( $atts, $content = null ) {
		extract( shortcode_atts( array(
	        	'id' => '',
	        	'class' => '',
	        	'brando_alert_massage_premade_style' => '',
	        	'brando_alert_massage_type' => '',
	        	'brando_message_icon' => '',
	        	'brando_highlight_title' => '',
	        	'brando_subtitle' => '',
	        	'show_close_button' => '',
	        	'custom_icon' => '',
                'custom_icon_image' => '',
                'brando_custom_image_srcset' => 'full',
                'title_settings' => '',
                'subtitle_settings' => ''
	        ), $atts ) );
		$output = $fontsettings_title_id = $fontsettings_title_class = $fontsettings_subtitle_id = $fontsettings_subtitle_class = '';
		global $font_settings_array;
		$id = ($id) ? ' id="'.$id.'"' : '';
		$class = ( $class ) ? ' '.$class : '';
		$brando_alert_massage_premade_style = ( $brando_alert_massage_premade_style ) ? $brando_alert_massage_premade_style : '';
		$brando_alert_massage_type = ( $brando_alert_massage_type ) ? ' alert-'.$brando_alert_massage_type : '';
		$brando_message_icon = ( $brando_message_icon ) ? $brando_message_icon : '';

		//New Font Awesome Icons
        $fa_icons_solid = brando_fontawesome_solid();
        $fa_icons_reg = brando_fontawesome_reg();
        $fa_icons_brand = brando_fontawesome_brand();
        $fa_icon_old = brando_fontawesome_old();
        $font_awesome_fa_icons = explode(' ',trim($brando_message_icon));

        if($font_awesome_fa_icons[0] == 'fa'){
            $brando_message_icon = substr(strstr($brando_message_icon," "), 1);

            if(array_key_exists($brando_message_icon, $fa_icon_old)){
                foreach ($fa_icon_old as $key => $value) {
                    if($brando_message_icon == $key){
                        $brando_message_icon = $value;
                        break;
                    }
                }
            }else if(in_array($brando_message_icon, $fa_icons_solid)){
                $brando_message_icon = 'fas '.$brando_message_icon;
            }else if(in_array($brando_message_icon, $fa_icons_reg)){
                $brando_message_icon = 'far '.$brando_message_icon;
            }else if(in_array($brando_message_icon, $fa_icons_brand)){
                $brando_message_icon = 'fab '.$brando_message_icon;
            }else{
                $brando_message_icon = '';
            }
        }
		/* Image Alt, Title, Caption */

		$brando_highlight_title = ( $brando_highlight_title ) ? $brando_highlight_title : '';
		$brando_subtitle = ( $brando_subtitle ) ? $brando_subtitle : '';
		$show_close_button = ( $show_close_button ) ? '<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>' : '';

		//Font Settings For Title
		if( !empty( $title_settings ) ) {
		    $fontsettings_title_id = uniqid('brando-font-setting-');
		    $responsive_style_title = brando_Responsive_font_settings::generate_css( $title_settings, $fontsettings_title_id );
		    $fontsettings_title_class = ' '.$fontsettings_title_id;
		}
		( !empty( $responsive_style_title ) ) ? $font_settings_array[] = $responsive_style_title : '';
		//Font Settings For Sub Title
		if( !empty( $subtitle_settings ) ) {
		    $fontsettings_subtitle_id = uniqid('brando-font-setting-');
		    $responsive_style_subtitle = brando_Responsive_font_settings::generate_css( $title_settings, $fontsettings_subtitle_id );
		    $fontsettings_subtitle_class = ' '.$fontsettings_subtitle_id;
		}
		( !empty( $responsive_style_subtitle ) ) ? $font_settings_array[] = $responsive_style_subtitle : '';

		// custom icon image
	    $brando_custom_image_srcset = ($brando_custom_image_srcset) ? $brando_custom_image_srcset : 'full';
	    $custom_icon_image = ( $custom_icon_image ) ? $custom_icon_image : '';

		switch ($brando_alert_massage_premade_style) 
		{
			case 'alert-massage-style-1':

			   $output .= ' <div class="alert-style1">';
	                $output .= '<div'.$id.' class="alert'.$brando_alert_massage_type.$class.'" role="alert">';
	                	if( $custom_icon == 1 && !empty( $custom_icon_image ) ) {
		                    $output .= wp_get_attachment_image( $custom_icon_image, $brando_custom_image_srcset, '', array( 'class' => 'icon-image' ) );
		                }elseif($brando_message_icon){
                           $output .= '<i class="'.$brando_message_icon.'"></i>';
                        }
                        if($brando_highlight_title || $brando_subtitle){
                 	        $output .= '<span class="'.$fontsettings_subtitle_class.'">';
	                 	       	if($brando_highlight_title){
	                           		$output .= '<strong class="'.$fontsettings_title_class.'">'.$brando_highlight_title.'</strong> ';
	                       		}
	                           $output .= $brando_subtitle;
                            $output .= '</span>';
                        }        
                    $output .= '</div>';
                $output .= '</div>';
                
            break;

            case 'alert-massage-style-2':

		        $output .= '<div'.$id.' role="alert" class="alert'.$brando_alert_massage_type.$class.' fade in">';
		        	if( $custom_icon == 1 && !empty( $custom_icon_image ) ) {
		                    $output .= wp_get_attachment_image( $custom_icon_image, $brando_custom_image_srcset, '', array( 'class' => 'icon-image' ) );
		            }elseif($brando_message_icon){
						$output .= '<i class="'.$brando_message_icon.$brando_alert_massage_type.'"></i>';
					}
					if($brando_highlight_title || $brando_subtitle){
		                $output .= ' <span class="'.$fontsettings_subtitle_class.'">';
			                $output .= '<strong class="'.$fontsettings_title_class.'">'.$brando_highlight_title.'</strong> ';
			                $output .= $brando_subtitle;
		                $output .= '</span>';
	                }
	                $output .= $show_close_button;
	            $output .= '</div>';

            break;

			case 'alert-massage-style-3':

			   $output .= '<div'.$id.' role="alert" class="alert'.$brando_alert_massage_type.$class.' fade in">';
					if($brando_highlight_title || $brando_subtitle){
						$output .= '<span class="'.$fontsettings_subtitle_class.'">';
							if($brando_highlight_title){
								$output .= '<strong class="'.$fontsettings_title_class.'">'.$brando_highlight_title.'</strong> ';
							}
							$output .= $brando_subtitle;
						$output .= '</span>';
					}
					$output .= $show_close_button;
	            $output .= '</div>';

			break;

            case 'alert-massage-style-4':

				$output .= '<div class="alert-style2">';
					$output .= '<div'.$id.' role="alert" class="alert'.$brando_alert_massage_type.$class.'">';
						if($brando_highlight_title || $brando_subtitle){
							$output .= '<span class="'.$fontsettings_subtitle_class.'">';
								if($brando_highlight_title){
									$output .= '<strong class="'.$fontsettings_title_class.'">'.$brando_highlight_title.'</strong> ';
								}
								$output .= $brando_subtitle;
							$output .= '</span>';
						}
						$output .= $show_close_button;
		            $output .= '</div>';
		        $output .= '</div>';

		    break;

			case 'alert-massage-style-5':

				$output .= '<div'.$id.' role="alert" class="alert alert-block fade in'.$brando_alert_massage_type.$class.'">';
					$output .= $show_close_button;
					if($brando_highlight_title){
						$output .= '<span class="margin-two no-margin-top no-margin-lr alt-font font-weight-700 text-medum text-uppercase'.$brando_alert_massage_type.''.$fontsettings_title_class.'">'.$brando_highlight_title.'</span>';
					}
					if($brando_subtitle){
						$output .= '<p class="'.$fontsettings_subtitle_class.'">'.$brando_subtitle.'</p>';
					}
		        $output .= '</div>';

			break;
		}
	    return $output;
	}
}
add_shortcode('brando_alert_massage','brando_alert_massage_shortcode');