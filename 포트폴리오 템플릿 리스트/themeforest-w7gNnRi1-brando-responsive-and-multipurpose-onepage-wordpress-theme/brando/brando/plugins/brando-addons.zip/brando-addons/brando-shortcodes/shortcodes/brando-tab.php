<?php
/**
 * Shortcode For Tabs
 *
 * @package Brando
 */
?>
<?php
/*-----------------------------------------------------------------------------------*/
/* Tabs */
/*-----------------------------------------------------------------------------------*/

$brando_tabs_style='';
if ( ! function_exists( 'brando_tabs' ) ) {
  function brando_tabs( $atts, $content = null ) {
    extract( shortcode_atts( array(
                'id'        => '',
                'class'     => '',
                'tabs_style' => '',
                'active_tab' => '',
                'tabs_alignment' => '',
                'custom_icon' => '',
                'custom_icon_image' => '',
                'brando_custom_image_srcset' => 'full',
                'brando_title_color' => '',
                'brando_border_color' => '',
                'brando_token_class' => '',
                'title_settings' => '',
            ), $atts ) );
    $output = '';

    global $brando_tabs_style , $brando_global_tabs, $tz_featured_array, $font_settings_array;
    $brando_global_tabs = array();
    $brando_tabs_style = $tabs_style;
    $pre_define_tab_style = '';     
    do_shortcode( $content );
    if( empty( $brando_global_tabs ) ) { return; }
    $id = ( $id ) ? ' id="'.$id.'"' : '';
    $class = ( $class ) ? ' '.$class : '';
    $active_tab = ( $active_tab ) ? $active_tab : '1';
    $pre_define_tab_style = ( $tabs_style ) ? $tabs_style : '';
    $tabs_alignment = ( $tabs_alignment ) ? ' '.$tabs_alignment : '';
    $brando_token_class = ( $brando_token_class ) ? $brando_token_class : '';

    ( $brando_title_color && $brando_token_class ) ? $tz_featured_array[] = '.'.$brando_token_class.' .nav-tabs li a,.'.$brando_token_class.' .nav-tabs>li.active>a:focus, .'.$brando_token_class.' .nav-tabs li a i, .'.$brando_token_class.' .nav-tabs li:active a i { color:'.$brando_title_color.' !important;}' : '';
    ( $brando_border_color && $brando_token_class ) ? $tz_featured_array[] = '.'.$brando_token_class.' .nav-tabs li.active a, .'.$brando_token_class.' .nav-tabs li a:hover, .'.$brando_token_class.' .nav-tabs li a:focus, .'.$brando_token_class.' .nav-tabs>li.active>a:focus { border-bottom-color:'.$brando_border_color.';}' : '';

    //Font Settings For Title
    $fontsettings_title_class = $fontsettings_title_id = $responsive_style = '';
    if( !empty( $title_settings ) ) {
        $fontsettings_title_id = uniqid('brando-font-setting-');
        $responsive_style = brando_Responsive_font_settings::generate_css( $title_settings, $fontsettings_title_id );
        $fontsettings_title_class = ' '.$fontsettings_title_id;
    }
    ( !empty( $responsive_style ) ) ? $font_settings_array[] = $responsive_style : '';
    
    /* For uniqtab id */
    $tabuniqtab = time().'-'.mt_rand();

    switch ($pre_define_tab_style) {
        case 'tab-style1':
          $tabs_style = 'tab-style5';
        break;
        case 'tab-style2':
          $tabs_style = 'tab-style6';
        break;
        case 'tab-style3':
          $tabs_style = 'tab-style7';
        break;
        case 'tab-style4':
          $tabs_style = 'tab-style8';
        break;
        case 'tab-style5':
          $tabs_style = 'tab-style9';
        break;
        case 'tab-style6':
          $tabs_style = 'tab-style-1';
        break;
        case 'tab-style7':
          $tabs_style = 'tab-style-3';
        break;
        case 'tab-style8':
          $tabs_style = 'tab-style-2';
        break;
        case 'tab-style9':
          $tabs_style = 'tab-style-4';
        break;
    }
    switch ($tabs_style) {

      case 'tab-style-1':
  
        $i = $j= 1;
        $output .= '<div'.$id.' class="col-md-4 col-sm-12 col-xs-12'.$class.' '.$brando_token_class.'">';
          $output .= '<ul class="nav nav-tabs '.$tabs_style.' no-border alt-font text-large'.$tabs_alignment.'" role="tablist">';
            foreach( $brando_global_tabs as $key => $tab) {
              $title =  $tab['atts']['title'];
              $tab_icon  =  ( (isset($tab['atts']['show_icon']) == 1) && ( !empty($tab['atts']['tab_icon']) ) ) ? $tab['atts']['tab_icon'] : '';

              /* New Font Awesome Icons Start*/
              $fa_icons_solid = brando_fontawesome_solid();
              $fa_icons_reg = brando_fontawesome_reg();
              $fa_icons_brand = brando_fontawesome_brand();
              $fa_icon_old = brando_fontawesome_old(); 
              $font_awesome_fa_icons = explode(' ',trim($tab_icon));

              if($font_awesome_fa_icons[0] == 'fa'){
                  $tab_icon = substr(strstr($tab_icon," "), 1);

                  if(array_key_exists($tab_icon, $fa_icon_old)){
                      foreach ($fa_icon_old as $key => $value) {
                          if($tab_icon == $key){
                              $tab_icon = $value;
                              break;
                          }
                      }
                  }else if(in_array($tab_icon, $fa_icons_solid)){
                      $tab_icon = 'fas '.$tab_icon;
                  }else if(in_array($tab_icon, $fa_icons_reg)){
                      $tab_icon = 'far '.$tab_icon;
                  }else if(in_array($tab_icon, $fa_icons_brand)){
                      $tab_icon = 'fab '.$tab_icon;
                  }else{
                      $tab_icon = '';
                  }
              }
              /* New Font Awesome Icons End*/

              $custom_icon  =   (isset($tab['atts']['custom_icon']) == 1) ? $tab['atts']['custom_icon'] : '';
              $custom_icon_image  =  ( !empty($tab['atts']['custom_icon_image'] ) ) ? $tab['atts']['custom_icon_image'] : '';

              $brando_custom_image_srcset  =  ( !empty($tab['atts']['brando_custom_image_srcset'] ) ) ? $tab['atts']['brando_custom_image_srcset'] : 'full';

              $active = ( ( $key + 1 ) == $active_tab ) ? 'active' : '';
              $output .= '<li role="presentation" class="sm-no-margin '.$active.'">';
                $output .= '<a href="#brando-'.$tabuniqtab.'-'.$key.'" role="tab" data-toggle="tab" class="'.$fontsettings_title_class.'">';
                  if( $custom_icon == 1 && !empty( $custom_icon_image ) ) {
                      $output .= wp_get_attachment_image( $custom_icon_image, $brando_custom_image_srcset, '', array( 'class' => 'icon-image' ) );
                  }elseif($tab_icon){
                    $output .= '<i class="'.$tab_icon.'"></i>';
                  }
                  if(($title) && (isset($tab['atts']['show_title']) == 1)):
                    $output .= esc_html($title);
                  endif;
                $output .= '</a>';
              $output .= '</li>';
              $j++;
            } 
          $output .= '</ul>';
        $output .= '</div>';
        $output .= '<div class="col-md-7 col-sm-12 col-xs-12 col-md-offset-1 sm-margin-six-top">';
          $output .= '<div class="tab-content">';
            foreach ($brando_global_tabs as $key => $tab) {
              $active_content = ( ( $key + 1 ) == $active_tab ) ? 'in active' : '';
              $output .= '<div role="tabpanel" class="tab-pane fade '.$active_content.'" id="brando-'.$tabuniqtab.'-'.$key.'">';
                 $output .=  do_shortcode($tab['content']);
              $output .= '</div>';
              $i++;
            }   
          $output .= '</div>';
        $output .= '</div>';
      break;

      case 'tab-style-2':
        $i = $j = 1;
        $output .= '<div'.$id.' class="tab-content clearfix'.$class.'">';
            foreach ($brando_global_tabs as $key => $tab) {
              $active_content = ( ( $key + 1 ) == $active_tab ) ? 'in active' : '';
              $output .= '<div role="tabpanel" class="tab-pane fade '.$active_content.'" id="brando-'.$tabuniqtab.'-'.$key.'">';
                 $output .=  do_shortcode($tab['content']);
              $output .= '</div>';
              $i++;
            }   
        $output .= '</div>';
        
        $output .= '<ul class="'.$tabs_style.' nav nav-tabs alt-font font-weight-600 text-uppercase no-border text-center margin-seven-top xs-margin-eighteen-top '.$brando_token_class.'" role="tablist">';
          foreach( $brando_global_tabs as $key => $tab) {
            $title =  $tab['atts']['title'];
            $tab_icon  =  ( (isset($tab['atts']['show_icon']) == 1) && ( !empty($tab['atts']['tab_icon']) ) ) ? $tab['atts']['tab_icon'] : '';
            /* New Font Awesome Icons Start*/
            $fa_icons_solid = brando_fontawesome_solid();
            $fa_icons_reg = brando_fontawesome_reg();
            $fa_icons_brand = brando_fontawesome_brand();
            $fa_icon_old = brando_fontawesome_old(); 
            $font_awesome_fa_icons = explode(' ',trim($tab_icon));

            if($font_awesome_fa_icons[0] == 'fa'){
                $tab_icon = substr(strstr($tab_icon," "), 1);

                if(array_key_exists($tab_icon, $fa_icon_old)){
                    foreach ($fa_icon_old as $key => $value) {
                        if($tab_icon == $key){
                            $tab_icon = $value;
                            break;
                        }
                    }
                }else if(in_array($tab_icon, $fa_icons_solid)){
                    $tab_icon = 'fas '.$tab_icon;
                }else if(in_array($tab_icon, $fa_icons_reg)){
                    $tab_icon = 'far '.$tab_icon;
                }else if(in_array($tab_icon, $fa_icons_brand)){
                    $tab_icon = 'fab '.$tab_icon;
                }else{
                    $tab_icon = '';
                }
            }
            /* New Font Awesome Icons End*/

            $custom_icon  =   (isset($tab['atts']['custom_icon']) == 1) ? $tab['atts']['custom_icon'] : '';
            $custom_icon_image  =  ( !empty($tab['atts']['custom_icon_image'] ) ) ? $tab['atts']['custom_icon_image'] : '';

            $brando_custom_image_srcset  =  ( !empty($tab['atts']['brando_custom_image_srcset'] ) ) ? $tab['atts']['brando_custom_image_srcset'] : 'full';
            
            $active = ( ( $key + 1 ) == $active_tab ) ? 'active' : '';
            $output .= '<li role="presentation" class="'.$active.' xs-display-block xs-no-margin">';
              $output .= '<a href="#brando-'.$tabuniqtab.'-'.$key.'" class="xs-display-inline-block'.$fontsettings_title_class.'" role="tab" data-toggle="tab">';
                if( $custom_icon == 1 && !empty( $custom_icon_image ) ) {
                    $output .= wp_get_attachment_image( $custom_icon_image, $brando_custom_image_srcset, '', array( 'class' => 'icon-image' ) );
                  }elseif($tab_icon){
                    $output .= '<i class="'.$tab_icon.'"></i>';
                  }
                if(($title) && (isset($tab['atts']['show_title']) == 1)):
                  $output .= esc_html($title);
                endif;  
              $output .= '</a>';
        
            $output .= '</li>';
            $j++;
          } 
        $output .= '</ul>';
      break;

      case 'tab-style-3':
        $i = $j= 1;
        $output .= '<div'.$id.' class="architecture-section no-padding-lr md-margin-three-lr xs-no-padding-top xs-no-margin-lr '.$tabs_style.$class.' '.$brando_token_class.'">';
            $output .= '<ul class="nav nav-tabs alt-font text-uppercase no-border font-weight-700'.$tabs_alignment.'" role="tablist">';
              foreach( $brando_global_tabs as $key => $tab) {
                $title =  $tab['atts']['title'];
                $tab_icon  =  ( (isset($tab['atts']['show_icon']) == 1) && ( !empty($tab['atts']['tab_icon']) ) ) ? $tab['atts']['tab_icon'] : '';

                /* New Font Awesome Icons Start*/
                $fa_icons_solid = brando_fontawesome_solid();
                $fa_icons_reg = brando_fontawesome_reg();
                $fa_icons_brand = brando_fontawesome_brand();
                $fa_icon_old = brando_fontawesome_old(); 
                $font_awesome_fa_icons = explode(' ',trim($tab_icon));

                if($font_awesome_fa_icons[0] == 'fa'){
                    $tab_icon = substr(strstr($tab_icon," "), 1);

                    if(array_key_exists($tab_icon, $fa_icon_old)){
                        foreach ($fa_icon_old as $key => $value) {
                            if($tab_icon == $key){
                                $tab_icon = $value;
                                break;
                            }
                        }
                    }else if(in_array($tab_icon, $fa_icons_solid)){
                        $tab_icon = 'fas '.$tab_icon;
                    }else if(in_array($tab_icon, $fa_icons_reg)){
                        $tab_icon = 'far '.$tab_icon;
                    }else if(in_array($tab_icon, $fa_icons_brand)){
                        $tab_icon = 'fab '.$tab_icon;
                    }else{
                        $tab_icon = '';
                    }
                }
                /* New Font Awesome Icons End*/
                $custom_icon  =   (isset($tab['atts']['custom_icon']) == 1) ? $tab['atts']['custom_icon'] : '';
                $custom_icon_image  =  ( !empty($tab['atts']['custom_icon_image'] ) ) ? $tab['atts']['custom_icon_image'] : '';

                $brando_custom_image_srcset  =  ( !empty($tab['atts']['brando_custom_image_srcset'] ) ) ? $tab['atts']['brando_custom_image_srcset'] : 'full';
                
                $active = ( ( $key + 1 ) == $active_tab ) ? 'active' : '';
                $output .= '<li role="presentation" class="xs-display-block xs-margin-five-bottom '.$active.'">';
                  $output .= '<a href="#brando-'.$tabuniqtab.'-'.$key.'" class="xs-display-inline'.$fontsettings_title_class.'" role="tab" data-toggle="tab">';
                    if( $custom_icon == 1 && !empty( $custom_icon_image ) ) {
                        $output .= wp_get_attachment_image( $custom_icon_image, $brando_custom_image_srcset, '', array( 'class' => 'icon-image' ) );
                    }elseif($tab_icon){
                      $output .= '<i class="'.$tab_icon.'"></i>';
                    }
                    if(($title) && (isset($tab['atts']['show_title']) == 1)):
                      $output .= esc_html($title);
                    endif;
                  $output .= '</a>';
                $output .= '</li>';
                $j++;
              } 
            $output .= '</ul>';
        $output .= '<div class="tab-content clearfix margin-ten-top sm-margin-five-top">';
            foreach ($brando_global_tabs as $key => $tab) {
              $active_content = ( ( $key + 1 ) == $active_tab ) ? 'in active' : '';
              $output .= '<div role="tabpanel" class="tab-pane fade '.$active_content.'" id="brando-'.$tabuniqtab.'-'.$key.'">';
                 $output .=  do_shortcode($tab['content']);
              $output .= '</div>';
              $i++;
            }   
        $output .= '</div>';
      $output .= '</div>';
      break;

      case 'tab-style-4':
        $output .= '<div'.$id.' class="'.$tabs_style.$class.' '.$brando_token_class.'">';
          $output .= '<ul class="nav nav-tabs alt-font display-inline-block text-uppercase font-weight-600 xs-width-100 xs-no-border margin-five-bottom '.$tabs_style.$class.$tabs_alignment.'" role="tablist">';
            foreach( $brando_global_tabs as $key => $tab) {
                    $title      =  $tab['atts']['title'];
                    $tab_icon  =  ( (isset($tab['atts']['show_icon']) == 1) && ( !empty($tab['atts']['tab_icon']) ) ) ? $tab['atts']['tab_icon'] : '';
                    /* New Font Awesome Icons Start*/
                    $fa_icons_solid = brando_fontawesome_solid();
                    $fa_icons_reg = brando_fontawesome_reg();
                    $fa_icons_brand = brando_fontawesome_brand();
                    $fa_icon_old = brando_fontawesome_old(); 
                    $font_awesome_fa_icons = explode(' ',trim($tab_icon));

                    if($font_awesome_fa_icons[0] == 'fa'){
                        $tab_icon = substr(strstr($tab_icon," "), 1);

                        if(array_key_exists($tab_icon, $fa_icon_old)){
                            foreach ($fa_icon_old as $key => $value) {
                                if($tab_icon == $key){
                                    $tab_icon = $value;
                                    break;
                                }
                            }
                        }else if(in_array($tab_icon, $fa_icons_solid)){
                            $tab_icon = 'fas '.$tab_icon;
                        }else if(in_array($tab_icon, $fa_icons_reg)){
                            $tab_icon = 'far '.$tab_icon;
                        }else if(in_array($tab_icon, $fa_icons_brand)){
                            $tab_icon = 'fab '.$tab_icon;
                        }else{
                            $tab_icon = '';
                        }
                    }
                    /* New Font Awesome Icons End*/
                    $custom_icon  =   (isset($tab['atts']['custom_icon']) == 1) ? $tab['atts']['custom_icon'] : '';
                    $custom_icon_image  =  ( !empty($tab['atts']['custom_icon_image'] ) ) ? $tab['atts']['custom_icon_image'] : '';

                    $brando_custom_image_srcset  =  ( !empty($tab['atts']['brando_custom_image_srcset'] ) ) ? $tab['atts']['brando_custom_image_srcset'] : 'full';
                    
                    $active = ( ( $key + 1 ) == $active_tab ) ? 'active' : '';
                    $output .= '<li class="xs-display-block xs-no-border '.$active.'">';
                      $output .= '<a href="#brando-'.$tabuniqtab.'-'.$key.'" data-toggle="tab" class="xs-display-block'.$fontsettings_title_class.'">';
                      if( $custom_icon == 1 && !empty( $custom_icon_image ) ) {
                        $output .= wp_get_attachment_image( $custom_icon_image, $brando_custom_image_srcset, '', array( 'class' => 'icon-image' ) );
                      }elseif($tab_icon){
                        $output .= '<i class="'.$tab_icon.'"></i>';
                      }
                      if(($title) && (isset($tab['atts']['show_title']) == 1)):
                        $output .= esc_html($title);
                      endif;
                      $output .= '</a>';
                    $output .= '</li>';
            }
          $output .= '</ul>';
          $output .= '<div class="tab-content clearfix">';
            foreach ($brando_global_tabs as $key => $tab) {
              $active_content = ( ( $key + 1 ) == $active_tab ) ? ' in active' : '';
              $title  = $tab['atts']['title'];
              $output .= '<div class="tab-pane fade'.$active_content.'" id="brando-'.$tabuniqtab.'-'.$key.'">';
                $output .=  do_shortcode($tab['content']);
              $output .=  '</div>';
            }
          $output .= '</div>';
        $output .= '</div>';
      break;

      case 'tab-style9':
        $output .= '<div'.$id.' class="'.$tabs_style.$class.' '.$brando_token_class.'">';
          $output .= '<ul class="nav nav-tabs margin-ten-bottom xs-margin-six-bottom'.$tabs_alignment.'">';
            foreach( $brando_global_tabs as $key => $tab) {
              $title      =  $tab['atts']['title'];
              $tab_icon  =  ( (isset($tab['atts']['show_icon']) == 1) && ( !empty($tab['atts']['tab_icon']) ) ) ? $tab['atts']['tab_icon'] : '';
              /* New Font Awesome Icons Start*/
              $fa_icons_solid = brando_fontawesome_solid();
              $fa_icons_reg = brando_fontawesome_reg();
              $fa_icons_brand = brando_fontawesome_brand();
              $fa_icon_old = brando_fontawesome_old(); 
              $font_awesome_fa_icons = explode(' ',trim($tab_icon));

              if($font_awesome_fa_icons[0] == 'fa'){
                  $tab_icon = substr(strstr($tab_icon," "), 1);

                  if(array_key_exists($tab_icon, $fa_icon_old)){
                      foreach ($fa_icon_old as $key => $value) {
                          if($tab_icon == $key){
                              $tab_icon = $value;
                              break;
                          }
                      }
                  }else if(in_array($tab_icon, $fa_icons_solid)){
                      $tab_icon = 'fas '.$tab_icon;
                  }else if(in_array($tab_icon, $fa_icons_reg)){
                      $tab_icon = 'far '.$tab_icon;
                  }else if(in_array($tab_icon, $fa_icons_brand)){
                      $tab_icon = 'fab '.$tab_icon;
                  }else{
                      $tab_icon = '';
                  }
              }
              /* New Font Awesome Icons End*/
              $custom_icon  =   (isset($tab['atts']['custom_icon']) == 1) ? $tab['atts']['custom_icon'] : '';
              $custom_icon_image  =  ( !empty($tab['atts']['custom_icon_image'] ) ) ? $tab['atts']['custom_icon_image'] : '';

              $brando_custom_image_srcset  =  ( !empty($tab['atts']['brando_custom_image_srcset'] ) ) ? $tab['atts']['brando_custom_image_srcset'] : 'full';
              
              $active = ( ( $key + 1 ) == $active_tab ) ? ' active' : '';
              $output .= '<li class="nav'.$active.'">';
              $output .= '<a href="#brando-'.$tabuniqtab.'-'.$key.'" data-toggle="tab" class="'.$fontsettings_title_class.'">';
                if( $custom_icon == 1 && !empty( $custom_icon_image ) ) {
                      $output .= '<span>';
                        $output .= wp_get_attachment_image( $custom_icon_image, $brando_custom_image_srcset, '', array( 'class' => 'icon-image' ) );
                      $output .= '</span>';
                }elseif($tab_icon){
                  $output .= '<span><i class="'.$tab_icon.'"></i></span>';
                }
                if(($title) && (isset($tab['atts']['show_title']) == 1)):
                $output .= '<br><span class="text-small letter-spacing-3 margin-five font-weight-600 xs-letter-spacing-none xs-display-none">'.esc_html($title).'</span>';
              endif;
              $output .= '</a>';
              
              $output .= '</li>';
            }
          $output .= '</ul>';
          $output .= '<div class="tab-content">';
            foreach ($brando_global_tabs as $key => $tab) {
              $active_content = ( ( $key + 1 ) == $active_tab ) ? ' in active' : '';
              $title  = $tab['atts']['title'];
              $output .= '<div class="col-md-12 col-sm-12 text-center center-col tab-pane fade'.$active_content.'" id="brando-'.$tabuniqtab.'-'.$key.'">';
                $output .=  do_shortcode($tab['content']);
              $output .=  '</div>';
            }
            $output .= '</div>';
        $output .= '</div>';
      break;

      case 'tab-style7':
        $output .= '<div class="'.$tabs_style.$class.' '.$brando_token_class.'"'.$id.'>';
            $output .= '<div class="row">';
              $output .= '<div class="col-md-12 col-sm-12 col-xs-12">';
                $output .= '<ul class="nav nav-tabs nav-tabs-light text-uppercase'.$tabs_alignment.'">';
                  foreach( $brando_global_tabs as $key => $tab) {
                    $title      =  $tab['atts']['title'];
                    $tab_icon  =  ( (isset($tab['atts']['show_icon']) == 1) && ( !empty($tab['atts']['tab_icon']) ) ) ? $tab['atts']['tab_icon'] : '';
                    /* New Font Awesome Icons Start*/
                    $fa_icons_solid = brando_fontawesome_solid();
                    $fa_icons_reg = brando_fontawesome_reg();
                    $fa_icons_brand = brando_fontawesome_brand();
                    $fa_icon_old = brando_fontawesome_old(); 
                    $font_awesome_fa_icons = explode(' ',trim($tab_icon));

                    if($font_awesome_fa_icons[0] == 'fa'){
                        $tab_icon = substr(strstr($tab_icon," "), 1);

                        if(array_key_exists($tab_icon, $fa_icon_old)){
                            foreach ($fa_icon_old as $key => $value) {
                                if($tab_icon == $key){
                                    $tab_icon = $value;
                                    break;
                                }
                            }
                        }else if(in_array($tab_icon, $fa_icons_solid)){
                            $tab_icon = 'fas '.$tab_icon;
                        }else if(in_array($tab_icon, $fa_icons_reg)){
                            $tab_icon = 'far '.$tab_icon;
                        }else if(in_array($tab_icon, $fa_icons_brand)){
                            $tab_icon = 'fab '.$tab_icon;
                        }else{
                            $tab_icon = '';
                        }
                    }
                    /* New Font Awesome Icons End*/
                    $custom_icon  =   (isset($tab['atts']['custom_icon']) == 1) ? $tab['atts']['custom_icon'] : '';
                    $custom_icon_image  =  ( !empty($tab['atts']['custom_icon_image'] ) ) ? $tab['atts']['custom_icon_image'] : '';

                    $brando_custom_image_srcset  =  ( !empty($tab['atts']['brando_custom_image_srcset'] ) ) ? $tab['atts']['brando_custom_image_srcset'] : 'full';
                    
                    $active = ( ( $key + 1 ) == $active_tab ) ? ' active' : '';
                    // $output .= '<li class="nav'.$active.'">';
                    $output .= '<li class="no-margin xs-width-100 '.$active.'">';
                      $output .= '<a href="#brando-'.$tabuniqtab.'-'.$key.'" data-toggle="tab" class="'.$fontsettings_title_class.'">';
                        if( $custom_icon == 1 && !empty( $custom_icon_image ) ) {
                          $output .= wp_get_attachment_image( $custom_icon_image, $brando_custom_image_srcset, '', array( 'class' => 'icon-image' ) );
                        }elseif($tab_icon){
                          $output .= '<i class="'.$tab_icon.'"></i>';
                        }
                        if(($title) && (isset($tab['atts']['show_title']) == 1)){
                          $output .= esc_html($title);
                        }
                      $output .= '</a>';
                    $output .= '</li>';
                  }
                $output .= '</ul>';
              $output .= '</div>';
            $output .= '</div>';
          $output .= '<div class="tab-content">';
            foreach ($brando_global_tabs as $key => $tab) {
              $active_content = ( ( $key + 1 ) == $active_tab ) ? ' in active' : '';
              $title  = $tab['atts']['title'];
              $output .= '<div class="tab-pane fade'.$active_content.'" id="brando-'.$tabuniqtab.'-'.$key.'">';
                $output .=  do_shortcode($tab['content']);
              $output .=  '</div>';
            }
          $output .= '</div>';
        $output .= '</div>';
      break;

      case 'tab-style8':
        $output .= '<div class="'.$tabs_style.$class.' '.$brando_token_class.'"'.$id.'>';
          $output .= '<div class="row">';
            $output .= '<div class="tabs-left col-md-12 col-sm-12 col-xs-12">';
              $output .= '<ul class="nav nav-tabs nav-tabs-light'.$tabs_alignment.'">';
                foreach( $brando_global_tabs as $key => $tab) {
                  $title      =  $tab['atts']['title'];
                  $tab_icon  =  ( (isset($tab['atts']['show_icon']) == 1) && ( !empty($tab['atts']['tab_icon']) ) ) ? $tab['atts']['tab_icon'] : '';
                  /* New Font Awesome Icons Start*/
                  $fa_icons_solid = brando_fontawesome_solid();
                  $fa_icons_reg = brando_fontawesome_reg();
                  $fa_icons_brand = brando_fontawesome_brand();
                  $fa_icon_old = brando_fontawesome_old(); 
                  $font_awesome_fa_icons = explode(' ',trim($tab_icon));

                  if($font_awesome_fa_icons[0] == 'fa'){
                      $tab_icon = substr(strstr($tab_icon," "), 1);

                      if(array_key_exists($tab_icon, $fa_icon_old)){
                          foreach ($fa_icon_old as $key => $value) {
                              if($tab_icon == $key){
                                  $tab_icon = $value;
                                  break;
                              }
                          }
                      }else if(in_array($tab_icon, $fa_icons_solid)){
                          $tab_icon = 'fas '.$tab_icon;
                      }else if(in_array($tab_icon, $fa_icons_reg)){
                          $tab_icon = 'far '.$tab_icon;
                      }else if(in_array($tab_icon, $fa_icons_brand)){
                          $tab_icon = 'fab '.$tab_icon;
                      }else{
                          $tab_icon = '';
                      }
                  }
                  /* New Font Awesome Icons End*/
                  $custom_icon  =   (isset($tab['atts']['custom_icon']) == 1) ? $tab['atts']['custom_icon'] : '';
                  $custom_icon_image  =  ( !empty($tab['atts']['custom_icon_image'] ) ) ? $tab['atts']['custom_icon_image'] : '';

                  $brando_custom_image_srcset  =  ( !empty($tab['atts']['brando_custom_image_srcset'] ) ) ? $tab['atts']['brando_custom_image_srcset'] : 'full';
                  
                  $active = ( ( $key + 1 ) == $active_tab ) ? ' class="active"' : '';
                  $output .= '<li '.$active.'>';
                    $output .= '<a href="#brando-'.$tabuniqtab.'-'.$key.'" data-toggle="tab" class="'.$fontsettings_title_class.'">';
                      if( $custom_icon == 1 && !empty( $custom_icon_image ) ) {
                        $output .= wp_get_attachment_image( $custom_icon_image, $brando_custom_image_srcset, '', array( 'class' => 'icon-image' ) );
                      }elseif($tab_icon){
                        $output .= '<i class="'.$tab_icon.'"></i>';
                      }
                      if(($title) && (isset($tab['atts']['show_title']) == 1)){
                        $output .= esc_html($title);
                      }
                    $output .= '</a>';
                  $output .= '</li>';
                }
              $output .= '</ul>';
              $output .= '<div class="tab-content position-relative overflow-hidden">';
                foreach ($brando_global_tabs as $key => $tab) {
                  $active_content = ( ( $key + 1 ) == $active_tab ) ? ' in active' : '';
                  $title  = $tab['atts']['title'];
                  $output .= '<div class="tab-pane fade'.$active_content.'" id="brando-'.$tabuniqtab.'-'.$key.'">';
                    $output .=  do_shortcode($tab['content']);
                  $output .=  '</div>';
                }
              $output .= '</div>';
            $output .= '</div>';
          $output .= '</div>';
        $output .= '</div>';
      break;

      default:
        $output .= '<div class="'.$tabs_style.$class.' '.$brando_token_class.'"'.$id.'>';
          $output .= '<div class="row">';
            $output .= '<div class="col-md-12 col-sm-12 col-xs-12 xs-margin-five-bottom">';
              $output .= '<ul class="nav nav-tabs nav-tabs-light text-uppercase'.$tabs_alignment.'">';
                foreach( $brando_global_tabs as $key => $tab) {
                  $title      =  $tab['atts']['title'];
                  $tab_icon  =  ( (isset($tab['atts']['show_icon']) == 1) && ( !empty($tab['atts']['tab_icon']) ) ) ? $tab['atts']['tab_icon'] : '';
                  /* New Font Awesome Icons Start*/
                  $fa_icons_solid = brando_fontawesome_solid();
                  $fa_icons_reg = brando_fontawesome_reg();
                  $fa_icons_brand = brando_fontawesome_brand();
                  $fa_icon_old = brando_fontawesome_old(); 
                  $font_awesome_fa_icons = explode(' ',trim($tab_icon));

                  if($font_awesome_fa_icons[0] == 'fa'){
                      $tab_icon = substr(strstr($tab_icon," "), 1);

                      if(array_key_exists($tab_icon, $fa_icon_old)){
                          foreach ($fa_icon_old as $key => $value) {
                              if($tab_icon == $key){
                                  $tab_icon = $value;
                                  break;
                              }
                          }
                      }else if(in_array($tab_icon, $fa_icons_solid)){
                          $tab_icon = 'fas '.$tab_icon;
                      }else if(in_array($tab_icon, $fa_icons_reg)){
                          $tab_icon = 'far '.$tab_icon;
                      }else if(in_array($tab_icon, $fa_icons_brand)){
                          $tab_icon = 'fab '.$tab_icon;
                      }else{
                          $tab_icon = '';
                      }
                  }
                  /* New Font Awesome Icons End*/

                  $custom_icon  =   (isset($tab['atts']['custom_icon']) == 1) ? $tab['atts']['custom_icon'] : '';
                  $custom_icon_image  =  ( !empty($tab['atts']['custom_icon_image'] ) ) ? $tab['atts']['custom_icon_image'] : '';

                  $brando_custom_image_srcset  =  ( !empty($tab['atts']['brando_custom_image_srcset'] ) ) ? $tab['atts']['brando_custom_image_srcset'] : 'full';
                  
                  $active = ( ( $key + 1 ) == $active_tab ) ? ' class="active"' : '';
                  $output .= '<li '.$active.'  >';
                    $output .= '<a href="#brando-'.$tabuniqtab.'-'.$key.'" data-toggle="tab" class="'.$fontsettings_title_class.'">';
                    if( $custom_icon == 1 && !empty( $custom_icon_image ) ) {
                        $output .= wp_get_attachment_image( $custom_icon_image, $brando_custom_image_srcset, '', array( 'class' => 'icon-image' ) );
                    }elseif($tab_icon){
                      $output .= '<i class="'.$tab_icon.'"></i>';
                    }
                    if(($title) && (isset($tab['atts']['show_title']) == 1)){
                      $output .= esc_html($title);
                    }
                    $output .= '</a>';
                  $output .= '</li>';
                }
              $output .= '</ul>';
            $output .= '</div>';
          $output .= '</div>';
          $output .= '<div class="tab-content">';
            foreach ($brando_global_tabs as $key => $tab) {
              $active_content = ( ( $key + 1 ) == $active_tab ) ? ' in active' : '';
              $title  = $tab['atts']['title'];
              $output .= '<div class="tab-pane fade'.$active_content.'" id="brando-'.$tabuniqtab.'-'.$key.'">';
                $output .=  do_shortcode($tab['content']);
              $output .=  '</div>';
            }
          $output .= '</div>';
        $output .= '</div>';
      break;
    }
    return $output;
  }
}
add_shortcode( 'vc_tabs', 'brando_tabs' );

if ( ! function_exists( 'brando_tab' ) ) {
  function brando_tab( $atts, $content = null) {
    global $brando_global_tabs;
    $brando_global_tabs[]  = array( 'atts' => $atts, 'content' => $content );
    return;
  }
}
add_shortcode( 'vc_tab', 'brando_tab' );