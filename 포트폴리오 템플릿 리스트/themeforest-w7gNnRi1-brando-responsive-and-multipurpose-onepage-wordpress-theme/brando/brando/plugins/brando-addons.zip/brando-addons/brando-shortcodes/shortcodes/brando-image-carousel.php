<?php
/**
 * Shortcode For Image Carousel
 *
 * @package Brando
 */
?>
<?php 
/*-----------------------------------------------------------------------------------*/
/* Image Carousel */
/*-----------------------------------------------------------------------------------*/


function brando_image_carousel_shortcode( $atts, $content = null ) {
    extract( shortcode_atts( array(
    		'show_pagination' 						=> '',
    		'show_pagination_style' 				=> '',
    		'show_pagination_color_style' 			=> '',
			'show_navigation' 						=> '',
			'show_navigation_style' 				=> '',
            'lightbox_gallery'                      => '1',
			'show_cursor_color_style' 				=> '',	
			'transition_style'						=> '',
			'transition_animation_out' 				=> '',
			'loop'									=> '',
			'brando_image_carousel_itemsdesktop' 	=> '5',
            'brando_image_carousel_itemsminidesktop'=> '3',
            'brando_image_carousel_itemstablet' 	=> '2',
            'brando_image_carousel_itemsmobile' 	=> '1',
			'autoplay'								=> '',
			'stoponhover'							=> '',
			'slidespeed'							=> '3000',
			'slidedelay'							=> '700',
			'brando_image_srcset'					=> '',
			'brando_image_carousel_id'				=> '',
			'brando_image_carousel_class' 			=>'',
            ), $atts ) );

    $output  = $slider_config = $slider_id = $slider_class = '';
    global $brando_srcset,$lightbox_slider_gallery,$brando_image_carousel_uniq_id;
    $transition_style = ( $transition_style ) ? $transition_style : '';
    $lightbox_slider_gallery = $lightbox_gallery;
    $brando_srcset = ($brando_image_srcset) ? $brando_image_srcset : 'full';
    
    // Pagination Style
    $pagination = ($show_pagination_style) ? brando_owl_pagination_slider_classes($show_pagination_style) : brando_owl_pagination_slider_classes('default');
    $pagination_style = ($show_pagination_color_style) ? brando_owl_pagination_color_classes($show_pagination_color_style) : brando_owl_pagination_color_classes('default');
    // Navigation Style
    $navigation = ( $show_navigation_style ) ? brando_owl_navigation_slider_classes( $show_navigation_style) : brando_owl_navigation_slider_classes('default') ;
    //Cursor Style
    $show_cursor_color_style = ( $show_cursor_color_style ) ? ' '.$show_cursor_color_style : ' cursor-black';
    // Check if slider id and class
    $brando_image_carousel_uniq_id = !empty( $brando_image_carousel_uniq_id ) ? $brando_image_carousel_uniq_id : 0;
    $brando_image_carousel_uniq_id = $brando_image_carousel_uniq_id + 1;
    $brando_slider_id = ( $brando_image_carousel_id ) ? $brando_image_carousel_id : 'image-carousel-'.$brando_image_carousel_uniq_id.'';
    $brando_slider_class = ( $brando_image_carousel_class ) ? $brando_image_carousel_class = ' '.$brando_image_carousel_class : '';

   	/* Image Carousel output start*/
   	$output .= '<div id="'.$brando_slider_id.'" class="owl-carousel owl-theme bottom-pagination brando-image-carousel '.$brando_slider_id.$slider_class.$pagination.$pagination_style.$navigation.$show_cursor_color_style.'">';
        $output .= do_shortcode($content);
    $output .= '</div>';
    /* End Image Carousel output start*/

    /* Add custom script Start*/
    $slidespeed = ( $slidespeed ) ? $slidespeed : '3000';
    if( $transition_style == 'fade' ){
        $transition_style = 'fadeIn';
        $transition_animation_out = 'fadeOut';
    }
    if( $transition_style == 'slide' ){
        $transition_style = '';
        $transition_animation_out = '';
    }
    if( $transition_style == 'goDown' ){
        $transition_style = 'slideInDown';
        $transition_animation_out = 'fadeOut';
    }
    if( $transition_style == 'backSlide' ){
        $transition_style = 'fadeOutLeft';
        $transition_animation_out = 'fadeInRight';
    }
    if( $transition_style == 'fadeUp' ){
        $transition_style = 'zoomIn';
        $transition_animation_out = 'fadeOut';
    }

    ( $show_navigation == 1 ) ? $slider_config .= 'nav: true,' : $slider_config .= 'nav: false,';
    ( $show_pagination == 1 ) ? $slider_config .= 'dots: true,' : $slider_config .= 'dots: false,';
    ( $transition_style ) ? $slider_config .= 'animateIn: "'.$transition_style .'",' : '';
    ( $transition_animation_out ) ? $slider_config .= 'animateOut: "'.$transition_animation_out .'",' : '';
    ( $autoplay == 1 ) ? $slider_config .= 'autoplay:true, autoplayTimeout: '.$slidespeed.',autoplaySpeed: '.$slidedelay.',' : $slider_config .= 'autoPlay: false,';
    ( $stoponhover == 1) ? $slider_config .= 'autoplayHoverPause: true, ' : $slider_config .= 'autoplayHoverPause: false, ';
    ( is_rtl() ) ? $slider_config .= 'rtl: true,' : '';
    ( $loop == 1 ) ? $slider_config .= 'loop: true,' : $slider_config .= 'loop: false,';
	( $brando_image_carousel_itemsdesktop || $brando_image_carousel_itemsminidesktop || $brando_image_carousel_itemstablet || $brando_image_carousel_itemsmobile ) ? $slider_config .= "responsive:{" : '';
	( $brando_image_carousel_itemsmobile ) ? $slider_config .= '0:{ items: '.$brando_image_carousel_itemsmobile.' },' : $slider_config .= '0:{ items: 1 },';
	( $brando_image_carousel_itemstablet ) ? $slider_config .= '700:{ items: '.$brando_image_carousel_itemstablet.'},' : $slider_config .= '700:{ items: 2 },';
	( $brando_image_carousel_itemsminidesktop ) ? $slider_config .= '991:{ items: '.$brando_image_carousel_itemsminidesktop.' },' : $slider_config .= '991:{ items: 3 },';
	( $brando_image_carousel_itemsdesktop ) ? $slider_config .= '1200:{ items: '.$brando_image_carousel_itemsdesktop.' },' : $slider_config .= '1200:{ items: 4 },';
	( $brando_image_carousel_itemsdesktop || $brando_image_carousel_itemsminidesktop || $brando_image_carousel_itemstablet || $brando_image_carousel_itemsmobile ) ? $slider_config .= "}," : '';
    $slider_config .= 'dotsSpeed: 400,';
    $slider_config .= 'navText: ["<i class=\'fas fa-angle-left\'></i>", "<i class=\'fas fa-angle-right\'></i>"],';	
    ob_start();?>
    <script type="text/javascript">jQuery(document).ready(function () { jQuery("#<?php echo $brando_slider_id ?>").owlCarousel({ <?php echo $slider_config;?> }); });</script>
    <?php 
    $script = ob_get_contents();
    ob_end_clean();
    $output .= $script;
    /* Add custom script End*/
    return $output;
}
add_shortcode( 'brando_image_carousel', 'brando_image_carousel_shortcode' );
 
function brando_image_carousel_content_shortcode( $atts, $content = null) {
    global $brando_srcset,$lightbox_slider_gallery;
    extract( shortcode_atts( array(
                'image' => '',
                'brando_image_srcset' => '',
            ), $atts ) );

    $output = '';
    $lightbox_gallery_class = ($lightbox_slider_gallery == 1) ? 'titlelightboxgallery' : '';
    $thumb = wp_get_attachment_url( $image );
    $brando_image_srcset = ( $brando_image_srcset ) ? $brando_image_srcset : '';
    /* Image Alt, Title, Caption */
   
    $img_lightbox_caption = brando_option_image_caption($image);
    $img_lightbox_title = brando_option_lightbox_image_title($image);
    $image_lightbox_caption = ( isset($img_lightbox_caption['caption']) && !empty($img_lightbox_caption['caption']) ) ? ' lightbox_caption="'.$img_lightbox_caption['caption'].'"' : '' ;
    $image_lightbox_title = ( isset($img_lightbox_title['title']) && !empty($img_lightbox_title['title']) ) ? ' title="'.$img_lightbox_title['title'].'"' : '' ;
                                
    $output .= '<div class="'.$lightbox_gallery_class.'">';
        if($lightbox_slider_gallery == 1){
        	$output .= '<a href="'.$thumb.'" class="lightboxgalleryitem"'.$image_lightbox_title.$image_lightbox_caption.'>';
        }
        		$output .= '<div class="item padding-five-lr owl-bg-img">';
                    $output .= wp_get_attachment_image( $image, $brando_srcset );
        		$output .= '</div>';
        if($lightbox_slider_gallery == 1){
        	$output .=  '</a>';
        }
    $output .= '</div>';
    return $output;
}
add_shortcode( 'brando_image_carousel_slide', 'brando_image_carousel_content_shortcode' );