<?php
/**
 * Shortcode For Blog Post Slider
 *
 * @package Brando
 */
?>
<?php
/*-----------------------------------------------------------------------------------*/
/* Blog Post Slider */
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists( 'brando_post_slider' ) ) {
    function brando_post_slider( $atts, $content = null ) {
        extract( shortcode_atts( array(
            'brando_post_slider_style' => '',
            'brando_post_slider_id' => '',
            'brando_post_slider_class' => '',
            'brando_categories_list' => '',
            'brando_show_post_number' => '',
            'brando_show_post_title' => '',
            'brando_show_post_meta' => '',
            'brando_show_excerpt' => '',
            'brando_excerpt_length' => '15',
            'brando_show_post_date' => '',
            'brando_date_format' => 'd m Y',
            'brando_post_per_page' => '3',
            'brando_post_per_page_desktop' => '',
            'brando_post_per_page_desktop_mini' => '',
            'brando_post_per_page_ipad' => '',
            'brando_post_per_page_mobile' => '',
            'show_pagination' => '',
            'show_pagination_style' => '',
            'show_pagination_color_style' => '',
            'show_navigation' => '',
            'show_navigation_style' => '',
            'show_cursor_color_style' => '',
            'loop' => '',
            'autoplay' => '3000',
            'stoponhover' => '',
            'slidespeed' => '',
            'slidedelay' => '700',
            'orderby' => '',
            'order' => '',
            'brando_show_separator' => '',
            'brando_sep_color' => '',
            'brando_seperator_height' => '2px',
            'brando_number_color' => '',
            'brando_title_color' => '',
            'brando_author_color' => '',
            'brando_date_color' => '',
            'brando_image_srcset' => 'full',
        ), $atts ) );

        $output = $slider_config = '';
        $style_array = array();
        $orderby = ( $orderby ) ? $orderby : 'date';
        $order = ( $order ) ? $order : 'DESC';
        $brando_date_format = ( $brando_date_format ) ? $brando_date_format : 'd m Y';
        $brando_sep_color = ( $brando_sep_color ) ? $style_array[] = 'background:'.$brando_sep_color.' !important;' : '';
        $brando_seperator_height = ( $brando_seperator_height ) ? $style_array[] = 'height:'.$brando_seperator_height.' !important;' : '';
        $brando_categories_list = ( $brando_categories_list ) ? $brando_categories_list : '';
        $pagination = ($show_pagination_style) ? brando_owl_pagination_slider_classes($show_pagination_style) : brando_owl_pagination_slider_classes('default');
        $pagination_style = ($show_pagination_color_style) ? brando_owl_pagination_color_classes($show_pagination_color_style) : brando_owl_pagination_color_classes('default');
        $navigation = ( $show_navigation_style ) ? brando_owl_navigation_slider_classes( $show_navigation_style) : brando_owl_navigation_slider_classes('default') ;
        $show_cursor_color_style = ( $show_cursor_color_style ) ? ' '.$show_cursor_color_style : ' cursor-black';
        $autoplay = ( $autoplay ) ? $autoplay : '';
        $brando_post_per_page = ( $brando_post_per_page ) ? $brando_post_per_page : '-1';
        $brando_post_per_page_desktop = ( $brando_post_per_page_desktop ) ? $brando_post_per_page_desktop : '3';
        $brando_post_per_page_desktop_mini = ( $brando_post_per_page_desktop_mini ) ? $brando_post_per_page_desktop_mini : '3';
        $brando_post_per_page_ipad = ( $brando_post_per_page_ipad ) ? $brando_post_per_page_ipad : '2';
        $brando_post_per_page_mobile = ( $brando_post_per_page_mobile ) ? $brando_post_per_page_mobile : '1';
        $brando_post_slider_id = ( $brando_post_slider_id ) ? $brando_post_slider_id : $brando_post_slider_style;
        $brando_post_slider_class = ( $brando_post_slider_class ) ? ' '.$brando_post_slider_class : '';
        $brando_image_srcset = ($brando_image_srcset) ? $brando_image_srcset : 'full';

        $style_property_list = implode(" ", $style_array);
        $sep_style = ( $style_property_list ) ? ' style="'.$style_property_list.'"' : '';

        // Color settings
        $brando_number_color = ( $brando_number_color ) ? ' style="color:'.$brando_number_color.' !important;"' : '';
        $brando_title_color = ( $brando_title_color ) ? ' style="color:'.$brando_title_color.' !important;"' : '';
        $brando_author_color = ( $brando_author_color ) ? ' style="color:'.$brando_author_color.' !important;"' : '';
        $brando_date_color = ( $brando_date_color ) ? ' style="color:'.$brando_date_color.' !important;"' : '';

        $args = array('post_type' => 'post',
                   'posts_per_page' => $brando_post_per_page,
                   'category_name' => $brando_categories_list,
                   'orderby' => $orderby,
                   'order' => $order,
                   );
        $brando_post_slider = new WP_Query( $args );
        $i = 1;
        $output .='<div id="'.$brando_post_slider_id.'" class="blog-post-style3 blog-slider owl-carousel bottom-pagination owl-theme '.$brando_post_slider_id.$brando_post_slider_class.$navigation.$pagination.$pagination_style.$show_cursor_color_style.'">';
            while ( $brando_post_slider->have_posts() ) : $brando_post_slider->the_post();

                $brando_post_classes = '';
                ob_start();
                    post_class();
                    $brando_post_classes .= ob_get_contents();
                ob_end_clean();

                $popup_id = 'blog-'.get_the_ID();

                $post_format = get_post_format( get_the_ID() );
                switch ( $brando_post_slider_style ) {
                    case 'post-slider-1':
                        if($i < 10){
                            $i = '0'.$i.'.';
                        }else{
                            $i = $i.'.';
                        }
                        $show_excerpt = ( $brando_show_excerpt == 1 ) ? wpautop(brando_get_the_excerpt_theme($brando_excerpt_length)) : wpautop(brando_get_the_excerpt_theme(15));
                        $output .= '<div '.$brando_post_classes.'>';
                            $output .='<article class="item col-md-12 no-padding">';
                                $output .='<div class="col-md-12 col-sm-12">';
                                    $output .='<div class="post-thumbnail overflow-hidden position-relative bg-dark-blue">';
                                        if($post_format == 'image'){
                                            ob_start();
                                                include BRANDO_ADDONS_ROOT . '/loop/loop-image.php';
                                                $output .= ob_get_contents();  
                                            ob_end_clean();  
                                        }elseif($post_format == 'gallery'){
                                            ob_start();
                                                include BRANDO_ADDONS_ROOT . '/loop/loop-gallery.php';
                                                $output .= ob_get_contents();  
                                            ob_end_clean();  
                                        }elseif($post_format == 'video'){
                                            ob_start();
                                                include BRANDO_ADDONS_ROOT . '/loop/loop-video.php';
                                                $output .= ob_get_contents();  
                                            ob_end_clean();  
                                        }elseif($post_format == 'quote'){
                                            ob_start();
                                                include BRANDO_ADDONS_ROOT . '/loop/loop-quote.php';
                                                $output .= ob_get_contents();  
                                            ob_end_clean();  
                                        }else{
                                            $output .=  '<div class="blog-image"><a href="'.get_permalink().'">';
                                                if ( has_post_thumbnail() ) {
                                                    $output .= get_the_post_thumbnail( get_the_ID(), $brando_image_srcset );
                                                }
                                            $output .=  '</a></div>';
                                        }
                                        if( $brando_show_post_date == 1 ){
                                            $output .='<span class="post-date text-small text-uppercase alt-font light-gray-text position-absolute bg-dark-blue published"'.$brando_date_color.'>'.get_the_date($brando_date_format).'</span><time class="updated display-none" datetime="'.esc_attr( get_the_modified_date( 'c' ) ).'">'.get_the_modified_date( $brando_date_format ).'</time>';
                                        }
                                    $output .='</div>';
                                    $output .='<div class="post-details display-inline-block text-left">';
                                        if( $brando_show_post_number == 1 ){
                                            $output .='<div class="col-md-2 col-sm-2 no-padding">';
                                                $output .='<span class="title-extra-large deep-orange-text md-title-large alt-font font-weight-700 display-block sm-display-none"'.$brando_number_color.'>'.$i.'</span>';
                                            $output .='</div>';
                                        }
                                        $output .='<div class="col-md-10 col-sm-12 no-padding">';
                                            if( $brando_show_post_title == 1 ){
                                                $output .='<span class="text-large text-uppercase md-text-medium display-block alt-font"><a href="'.get_permalink().'" class="light-gray-text entry-title"'.$brando_title_color.'>'.get_the_title().'</a></span>';
                                            }
                                            if( $brando_show_post_meta == 1 ){
                                                $output .='<span class="text-extra-small text-uppercase display-block alt-font medium-gray-text margin-one-top author vcard"'.$brando_author_color.'>'.__('Posted by ','brando-addons').'<a href="'.esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ).'" class="medium-gray-text url fn n"'.$brando_author_color.'>'.get_the_author().'</a></span>';
                                            }
                                            if( $brando_show_excerpt == 1 ){
                                                $output .='<div class="text-medium display-block no-margin-lr margin-five width-80 entry-content">'.$show_excerpt.'</div>';
                                            }
                                        $output .='</div>';
                                    $output .='</div>';
                                $output .='</div>';
                            $output .='</article>';
                        $output .='</div>';
                    break;
                    case 'post-slider-2':
                        if($i < 10){
                            $i = '0'.$i;
                        }
                        $show_excerpt = ( $brando_show_excerpt == 1 ) ? wpautop(brando_get_the_excerpt_theme($brando_excerpt_length)) : wpautop(brando_get_the_excerpt_theme(15));
                        $output .= '<div '.$brando_post_classes.'>';
                            $output .='<article class="item col-md-12 no-padding">';
                                $output .='<div class="col-md-12 col-sm-12">';
                                    $output .='<div class="post-thumbnail overflow-hidden position-relative bg-dark-blue">';
                                        if($post_format == 'image'){
                                            ob_start();
                                                include BRANDO_ADDONS_ROOT . '/loop/loop-image.php';
                                                $output .= ob_get_contents();  
                                            ob_end_clean();  
                                        }elseif($post_format == 'gallery'){
                                            ob_start();
                                                include BRANDO_ADDONS_ROOT . '/loop/loop-gallery.php';
                                                $output .= ob_get_contents();  
                                            ob_end_clean();  
                                        }elseif($post_format == 'video'){
                                            ob_start();
                                                include BRANDO_ADDONS_ROOT . '/loop/loop-video.php';
                                                $output .= ob_get_contents();  
                                            ob_end_clean();  
                                        }elseif($post_format == 'quote'){
                                            ob_start();
                                                include BRANDO_ADDONS_ROOT . '/loop/loop-quote.php';
                                                $output .= ob_get_contents();  
                                            ob_end_clean();  
                                        }else{
                                            $output .=  '<div class="blog-image"><a href="'.get_permalink().'">';
                                                if ( has_post_thumbnail() ) {
                                                    $output .= get_the_post_thumbnail( get_the_ID(), $brando_image_srcset );
                                                }
                                            $output .=  '</a></div>';
                                        }
                                        if( $brando_show_post_date == 1 ){
                                            $output .='<span class="post-date text-mediaum text-uppercase alt-font font-weight-600 position-absolute bg-light-gray published"'.$brando_date_color.'>'.get_the_date($brando_date_format).'</span><time class="updated display-none" datetime="'.esc_attr( get_the_modified_date( 'c' ) ).'">'.get_the_modified_date( $brando_date_format ).'</time>';
                                        }
                                    $output .='</div>';
                                    $output .='<div class="post-details display-inline-block text-left">';
                                        if( $brando_show_post_number == 1 ){
                                            $output .='<div class="col-md-2 col-sm-2 no-padding">';
                                                $output .='<span class="title-extra-large deep-orange-text alt-font deep-pink-dark-text display-block sm-display-none font-weight-700"'.$brando_number_color.'>'.$i.'</span>';
                                            $output .='</div>';
                                        }
                                        $output .='<div class="col-md-10 col-sm-12 no-padding">';
                                            if( $brando_show_post_title == 1 ){
                                                $output .='<span class="text-large font-weight-700 text-uppercase display-block alt-font entry-title"'.$brando_title_color.'>'.get_the_title().'</span>';
                                            }
                                            if( $brando_show_post_meta == 1 ){
                                                $output .='<span class="text-extra-small text-uppercase display-block alt-font medium-gray-text margin-one-half no-margin-lr no-margin-bottom author vcard"'.$brando_author_color.'>'.__('Posted by ','brando-addons').'<a href="'.esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ).'" class="medium-gray-text url fn n"'.$brando_author_color.'>'.get_the_author().'</a></span>';
                                            }
                                            if( $brando_show_excerpt == 1 ){
                                                $output .='<div class="text-medium display-block margin-three-tb width-80 entry-content">'.$show_excerpt.'</div>';
                                            }
                                            if( $brando_show_separator == 1 ){
                                                $output .= '<div class="separator-line-thick bg-turquoise-blue no-margin-lr no-margin-bottom"'.$sep_style.'></div>';
                                            }
                                        $output .='</div>';
                                    $output .='</div>';
                                $output .='</div>';
                            $output .='</article>';
                        $output .='</div>';
                    break;
                }
            $i++;    
            endwhile;
            wp_reset_postdata();
        $output .='</div>';

        /* Add custom script Start*/
        $slidespeed = ( $slidespeed ) ? $slidespeed : '3000';
        ( $show_navigation == 1 ) ? $slider_config .= 'nav: true,' : $slider_config .= 'nav: false,';
        ( $show_pagination == 1 ) ? $slider_config .= 'dots: true,' : $slider_config .= 'dots: false,';
        ( $autoplay == 1 ) ? $slider_config .= 'autoplay:true, autoplayTimeout: '.$slidespeed.',autoplaySpeed: '.$slidedelay.',' : $slider_config .= 'autoPlay: false,';
        ( $stoponhover == 1) ? $slider_config .= 'autoplayHoverPause: true, ' : $slider_config .= 'autoplayHoverPause: false, ';
        ( is_rtl() ) ? $slider_config .= 'rtl: true,' : '';
        ( $loop == 1 ) ? $slider_config .= 'loop:true,' : $slider_config .= 'loop: false,';
        ( $brando_post_per_page_desktop || $brando_post_per_page_desktop_mini || $brando_post_per_page_ipad || $brando_post_per_page_mobile ) ? $slider_config .= "responsive:{" : '';
        ( $brando_post_per_page_mobile ) ? $slider_config .= '0:{ items: '.$brando_post_per_page_mobile.' },' : $slider_config .= '0:{ items: 1 },';
        ( $brando_post_per_page_ipad ) ? $slider_config .= '700:{ items: '.$brando_post_per_page_ipad.'},' : $slider_config .= '700:{ items: 2 },';
        ( $brando_post_per_page_desktop_mini ) ? $slider_config .= '800:{ items: '.$brando_post_per_page_desktop_mini.' },' : $slider_config .= '800:{ items: 3 },';
        ( $brando_post_per_page_desktop ) ? $slider_config .= '1200:{ items: '.$brando_post_per_page_desktop.' },' : $slider_config .= '1200:{ items: 4 },';
        ( $brando_post_per_page_desktop || $brando_post_per_page_desktop_mini || $brando_post_per_page_ipad || $brando_post_per_page_mobile ) ? $slider_config .= "}," : '';
        $slider_config .= 'navText: ["<i class=\'fas fa-angle-left\'></i>", "<i class=\'fas fa-angle-right\'></i>"]';
        ob_start();?>
            <script type="text/javascript">jQuery(document).ready(function () { jQuery("#<?php echo $brando_post_slider_id ?>").owlCarousel({ <?php echo $slider_config;?> }); }); </script>

        <?php 
        $script = ob_get_contents();
        ob_end_clean();
        $output .= $script;
        /* Add custom script End*/
        return $output;
    }
}
add_shortcode( 'brando_post_slider', 'brando_post_slider' );