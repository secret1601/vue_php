<?php
/**
 * Shortcode For Coming soon
 *
 * @package Brando
 */
?>
<?php
/*-----------------------------------------------------------------------------------*/
/* Coming soon */
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists( 'brando_coming_soon_shortcode' ) ) {
    function brando_coming_soon_shortcode( $atts, $content = null ) {
        extract( shortcode_atts( array(
            'id' => '',
            'class' => '',
            'brando_coming_soon_type' => '',
            'brando_coming_soon_logo' => '',
            'brando_coming_soon_mp4' => '',
            'brando_coming_soon_ogg' => '',
            'brando_coming_soon_webm' => '',
            'brando_coming_soon_title' => '',
            'brando_coming_soon_title_color' => '',
            'brando_coming_soon_date' => '',
            'brando_coming_soon_notify_me_counter_color' => '',
            'brando_coming_soon_notify_me_show_form' => '',
            'brando_coming_soon_notify_placeholder' => '',
            'brando_coming_soon_notify_me_fb' => '',
            'brando_coming_soon_notify_me_fb_url' => '',
            'brando_coming_soon_notify_me_tw' => '',
            'brando_coming_soon_notify_me_tw_url' => '',
            'brando_coming_soon_notify_me_dr' => '',
            'brando_coming_soon_notify_me_dr_url' => '',
            'brando_coming_soon_notify_me_yt' => '',
            'brando_coming_soon_notify_me_yt_url' => '',
            'brando_coming_soon_notify_me_li' => '',
            'brando_coming_soon_notify_me_li_url' => '',
            'brando_coming_soon_notify_me_pi' => '',
            'brando_coming_soon_notify_me_pi_url' => '',
            'brando_coming_soon_notify_me_be' => '',
            'brando_coming_soon_notify_me_be_url' => '',
            'brando_coming_soon_notify_me_insta' => '',
            'brando_coming_soon_notify_me_insta_url' => '',
            'brando_coming_soon_custom_link' => '',
            'brando_token_class' => '',
            'brando_coming_soon_social_icon_color' => '',
            'brando_coming_soon_custom_newsletter' => '',
            'brando_custom_newsletter' => '',
            'title_settings' => '',
            'brando_time_counter_days_text' => 'Day',
            'brando_time_counter_hours_text' => 'Hours',
            'brando_time_counter_minutes_text' => 'Minutes',
            'brando_time_counter_seconds_text' => 'Seconds',
        ), $atts ) );
        
        global $tz_featured_array,$font_settings_array;
        $output =  $style = '';
        $brando_token_class = $brando_token_class.$id;
        $id = ($id) ? ' id='.$id : '';
        $class = ($class) ? ' '.$class : ''; 
        $brando_coming_soon_logo = ( $brando_coming_soon_logo ) ? $brando_coming_soon_logo : '';
        $brando_coming_soon_mp4 = ( $brando_coming_soon_mp4 ) ? $brando_coming_soon_mp4 : '';
        $brando_coming_soon_ogg = ( $brando_coming_soon_ogg ) ? $brando_coming_soon_ogg : '';
        $brando_coming_soon_webm = ( $brando_coming_soon_webm ) ? $brando_coming_soon_webm : '';
        $brando_coming_soon_title = ( $brando_coming_soon_title ) ? $brando_coming_soon_title : '';
        $brando_coming_soon_date = ( $brando_coming_soon_date ) ? $brando_coming_soon_date : '';
        $brando_coming_soon_notify_me_show_form = ( $brando_coming_soon_notify_me_show_form ) ? $brando_coming_soon_notify_me_show_form : '';
        $brando_coming_soon_notify_placeholder = ( $brando_coming_soon_notify_placeholder ) ? $brando_coming_soon_notify_placeholder : 'ENTER YOUR EMAIL ADDRESS';
        $brando_coming_soon_notify_me_fb_url = ( $brando_coming_soon_notify_me_fb_url ) ? $brando_coming_soon_notify_me_fb_url : '#';
        $brando_coming_soon_notify_me_tw_url = ( $brando_coming_soon_notify_me_tw_url ) ? $brando_coming_soon_notify_me_tw_url : '#';
        $brando_coming_soon_notify_me_dr_url = ( $brando_coming_soon_notify_me_dr_url ) ? $brando_coming_soon_notify_me_dr_url : '#';
        $brando_coming_soon_notify_me_yt_url = ( $brando_coming_soon_notify_me_yt_url ) ? $brando_coming_soon_notify_me_yt_url : '#';
        $brando_coming_soon_notify_me_li_url = ( $brando_coming_soon_notify_me_li_url ) ? $brando_coming_soon_notify_me_li_url : '#';
        $brando_coming_soon_notify_me_pi_url = ( $brando_coming_soon_notify_me_pi_url ) ? $brando_coming_soon_notify_me_pi_url : '#';
        $brando_coming_soon_notify_me_be_url = ( $brando_coming_soon_notify_me_be_url ) ? $brando_coming_soon_notify_me_be_url : '#';
        $brando_coming_soon_custom_link = ($brando_coming_soon_custom_link) ? $brando_coming_soon_custom_link : '';
        $brando_coming_soon_title_color = ( $brando_coming_soon_title_color ) ? ' style="color:'.$brando_coming_soon_title_color.' !important;"' : '';
        $brando_coming_soon_notify_me_counter_color = ( $brando_coming_soon_notify_me_counter_color ) ? ' style="color:'.$brando_coming_soon_notify_me_counter_color.' !important;"' : '';


        $brando_time_counter_days_text = ( $brando_time_counter_days_text ) ? $brando_time_counter_days_text : 'Day';
        $brando_time_counter_hours_text = ( $brando_time_counter_hours_text ) ? $brando_time_counter_hours_text : 'Hours';
        $brando_time_counter_minutes_text = ( $brando_time_counter_minutes_text ) ? $brando_time_counter_minutes_text : 'Minutes';
        $brando_time_counter_seconds_text = ( $brando_time_counter_seconds_text ) ? $brando_time_counter_seconds_text : 'Seconds';

        /* Social icon color */
        ( $brando_coming_soon_social_icon_color && $brando_token_class ) ? $tz_featured_array[] = '.'.$brando_token_class.' .footer-social a i{ color:'.$brando_coming_soon_social_icon_color.';}' : '';
        $brando_token_class = ( $brando_token_class ) ? ' '.$brando_token_class : '';
        
        //Font Settings For Title
        $fontsettings_title_class = $fontsettings_title_id = $responsive_style = '';
        if( !empty( $title_settings ) ) {
            $fontsettings_title_id = uniqid('brando-font-setting-');
            $responsive_style = brando_Responsive_font_settings::generate_css( $title_settings, $fontsettings_title_id );
            $fontsettings_title_class = ' '.$fontsettings_title_id;
        }
        ( !empty( $responsive_style ) ) ? $font_settings_array[] = $responsive_style : '';

        $output .= '<div'.$id.' class="coming-soon-bg owl-bg-img'.$class.$brando_token_class.'">';
          $output .= '<div class="position-relative container full-screen">';
            $output .= '<div class="slider-typography">';
                $output .= '<div class="slider-text-middle-main">';
                        $output .= '<div class="slider-text-middle">';
                            if( $brando_coming_soon_logo ){
                                $output .= '<a class="margin-seven-bottom xs-margin-eight-bottom display-inline-block" href="'.home_url('/').'">';
                                    $output .= wp_get_attachment_image( $brando_coming_soon_logo, 'full' , '', array( 'class' => 'img-responsive width-100' ) );
                                $output .= '</a>';
                            }
                            $output .= '<div class="row">';
                                $output .= '<div class="col-md-12 col-sm-12 col-xs-12 text-center margin-seven-bottom xs-margin-eight-bottom">';
                                    if( $brando_coming_soon_title || $brando_coming_soon_title_color ){
                                        $output .= '<span class="title-medium alt-font font-weight-600 text-uppercase xs-text-extra-large'.$fontsettings_title_class.'"'.$brando_coming_soon_title_color.'>'.$brando_coming_soon_title.'</span>';                      
                                    }
                                    if( $brando_coming_soon_date ){
                                        $output .= '<div id="counter-event" data-days-text="'.$brando_time_counter_days_text.'" data-hours-text="'.$brando_time_counter_hours_text.'" data-minutes-text="'.$brando_time_counter_minutes_text.'"  data-seconds-text="'.$brando_time_counter_seconds_text.'" data-enddate="'.$brando_coming_soon_date.'" class="countdown-timer text-center alt-font center-col margin-six-top"'.$brando_coming_soon_notify_me_counter_color.'></div>';
                                    }
                                $output .= '</div>';
                            $output .= '</div>';
                            $output .= '<div class="row">';
                            if(  $brando_coming_soon_notify_me_show_form == 1 || $brando_coming_soon_notify_me_fb == 1 || $brando_coming_soon_notify_me_tw == 1 || $brando_coming_soon_notify_me_dr == 1 || $brando_coming_soon_notify_me_yt == 1 || $brando_coming_soon_notify_me_li == 1){
                                $output .= '<div class="col-lg-5 col-md-6 center-col col-sm-8 col-xs-12 text-center">';
                                    if( $content  ){
                                        $output.= do_shortcode( brando_remove_wpautop($content) );
                                    }
                                    if( $brando_coming_soon_notify_me_show_form == 1 ){
                                        if( $brando_coming_soon_custom_newsletter == 1 ){
                                            $brando_custom_newsletter = str_replace( '`{`', '[', $brando_custom_newsletter );
                                            $brando_custom_newsletter = str_replace( '`}`', ']', $brando_custom_newsletter );
                                            $brando_custom_newsletter = str_replace( '``', '"', $brando_custom_newsletter );
                                            $output .= do_shortcode($brando_custom_newsletter);
                                        }else{
                                            if( defined( 'XYZ_EM_PLUGIN_FILE' ) ){
                                                $output .= '<form id="comingsoonscontactform" class="margin-eight-bottom" name="subscription"  action="'.esc_url( home_url() ).'/index.php?wp_nlm=subscribe" method="POST">';
                                                $output .= wp_nonce_field( 'xyz_em_subscription' );
                                                $output .= '<div id="success" class="no-margin-lr"></div>';
                                                $output .= '<input id="email"  type="text" class="form-control xyz_em_email"  name="xyz_em_email" placeholder="'.$brando_coming_soon_notify_placeholder.'">';
                                                $output .= '<button name="submit" id="submit_newsletter" class="submit_newsletter" ><i class="far fa-envelope"></i></button>';
                                                $output .= '</form>';
                                            }else{
                                                $output .= do_shortcode('[mc4wp_form id="6860"]');
                                            }
                                        }
                                    }
                                    if( $brando_coming_soon_notify_me_fb == 1 || $brando_coming_soon_notify_me_tw == 1 || $brando_coming_soon_notify_me_dr == 1 || $brando_coming_soon_notify_me_yt == 1 || $brando_coming_soon_notify_me_li == 1 ){
                                        $output .= '<div class="footer-social position-relative top4 ">';
                                            if( $brando_coming_soon_notify_me_fb == 1 ){
                                                $output .='<a href="'.$brando_coming_soon_notify_me_fb_url.'" target="_blank"><i class="fab fa-facebook-f white-text"></i></a>';
                                            }
                                            if( $brando_coming_soon_notify_me_tw == 1 ){
                                                $output .='<a href="'.$brando_coming_soon_notify_me_tw_url.'" target="_blank"><i class="fab fa-twitter white-text"></i></a>';
                                            }
                                            if( $brando_coming_soon_notify_me_dr == 1 ){
                                                $output .='<a href="'.$brando_coming_soon_notify_me_dr_url.'" target="_blank"><i class="fab fa-dribbble white-text"></i></a>';
                                            }
                                            if( $brando_coming_soon_notify_me_yt == 1 ){
                                                $output .='<a href="'.$brando_coming_soon_notify_me_yt_url.'" target="_blank"><i class="fab fa-youtube white-text"></i></a>';
                                            }
                                            if( $brando_coming_soon_notify_me_li == 1 ){
                                                $output .= '<a href="'.$brando_coming_soon_notify_me_li_url.'" target="_blank"><i class="fab fa-linkedin-in white-text"></i></a>';
                                            }
                                            if( $brando_coming_soon_notify_me_pi == 1 ){
                                                $output .= '<a href="'.$brando_coming_soon_notify_me_pi_url.'" target="_blank"><i class="fab fa-pinterest white-text"></i></a>';
                                            }
                                            if( $brando_coming_soon_notify_me_be == 1 ){
                                                $output .= '<a href="'.$brando_coming_soon_notify_me_be_url.'" target="_blank"><i class="fab fa-behance white-text"></i></a>';
                                            }
                                            if( $brando_coming_soon_notify_me_insta == 1 ){
                                                $output .= '<a href="'.$brando_coming_soon_notify_me_insta_url.'" target="_blank"><i class="fab fa-instagram white-text"></i></a>';
                                            }
                                            if( !empty( $brando_coming_soon_custom_link ) ) {
                                                $output .= nl2br( rawurldecode( base64_decode( strip_tags( $brando_coming_soon_custom_link ) ) ) );
                                            }
                                        $output .= '</div>';
                                    }   
                                    $output .= '</div>';
                                }
                            $output .= '</div>';
                        $output .= '</div>';    
                        $output .= '</div>';
                    $output .= '</div>';
                $output .= '</div>';
            $output .= '</div>';
        $output .= '</div>';
        
        return $output;
    }
}
add_shortcode( 'brando_coming_soon', 'brando_coming_soon_shortcode' );