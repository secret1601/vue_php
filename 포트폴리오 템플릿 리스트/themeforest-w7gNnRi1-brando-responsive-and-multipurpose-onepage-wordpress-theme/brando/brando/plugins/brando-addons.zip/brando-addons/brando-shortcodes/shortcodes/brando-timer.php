<?php
/**
 * Shortcode For Timer
 *
 * @package Brando
 */
?>
<?php
/*-----------------------------------------------------------------------------------*/
/* Timer */
/*-----------------------------------------------------------------------------------*/

if ( ! function_exists( 'brando_timer' ) ) {
    function brando_timer( $atts, $content = null ) {
        extract( shortcode_atts( array(
            'id' => '',
            'class' => '',
            'brando_timer_date' => '',
            'brando_timer_color' => '',
            'brando_time_counter_days_text' => 'Day',
            'brando_time_counter_hours_text' => 'Hours',
            'brando_time_counter_minutes_text' => 'Minutes',
            'brando_time_counter_seconds_text' => 'Seconds',
        ), $atts ) );
        
        $output = '';
        $id = ($id) ? ' id='.$id : '';
        $class = ($class) ? $class : 'counter-event'; 
        $brando_timer_date = ( $brando_timer_date ) ? $brando_timer_date : '';
        $brando_timer_color = ( $brando_timer_color ) ? ' style="color:'.$brando_timer_color.' !important;"' : '';

        // ver 1.7.6
        $brando_time_counter_days_text = ( $brando_time_counter_days_text ) ? $brando_time_counter_days_text : 'Day';
        $brando_time_counter_hours_text = ( $brando_time_counter_hours_text ) ? $brando_time_counter_hours_text : 'Hours';
        $brando_time_counter_minutes_text = ( $brando_time_counter_minutes_text ) ? $brando_time_counter_minutes_text : 'Minutes';
        $brando_time_counter_seconds_text = ( $brando_time_counter_seconds_text ) ? $brando_time_counter_seconds_text : 'Seconds';
        
        $output .='<div'.$id.' data-days-text="'.$brando_time_counter_days_text.'" data-hours-text="'.$brando_time_counter_hours_text.'" data-minutes-text="'.$brando_time_counter_minutes_text.'"  data-seconds-text="'.$brando_time_counter_seconds_text.'" data-enddate="'.$brando_timer_date.'" class="'.$class.' countdown-timer countdown white-text alt-font center-col margin-five-top sm-margin-eight-top"'.$brando_timer_color.'></div>';

        ob_start();
            ?>
            <script type="text/javascript">
                jQuery(document).ready(function () { 
                    var $CounterDay, $CounterHours, $CounterMinutes, $CounterSeconds = '';
                    var CounterDayattr = jQuery('.countdown.countdown-timer').attr('data-days-text');
                    if( typeof CounterDayattr !== typeof undefined && CounterDayattr !== false ) {
                        var $CounterDay = '<span>'+CounterDayattr+'</span>';
                    }
                    var CounterHoursattr = jQuery('.countdown.countdown-timer').attr('data-hours-text');
                    if( typeof CounterHoursattr !== typeof undefined && CounterHoursattr !== false ) {
                        var $CounterHours = '<span>'+CounterHoursattr+'</span>';
                    }
                    var CounterMinutesattr = jQuery('.countdown.countdown-timer').attr('data-minutes-text');
                    if( typeof CounterMinutesattr !== typeof undefined && CounterMinutesattr !== false ) {
                        var $CounterMinutes = '<span>'+CounterMinutesattr+'</span>';
                    }
                    var CounterSecondsattr = jQuery('.countdown.countdown-timer').attr('data-seconds-text');
                    if( typeof CounterSecondsattr !== typeof undefined && CounterSecondsattr !== false ) {
                        var $CounterSeconds = '<span>'+CounterSecondsattr+'</span>';
                    }

                    jQuery("<?php echo '.'.$class ?>").countdown(jQuery("<?php echo '.'.$class ?>").attr("data-enddate")).on('update.countdown', function (event) {
                        var $this = jQuery(this).html(event.strftime('' + '<div class="counter-container"><div class="counter-box first"><div class="number">%-D</div>'+$CounterDay+'</div>' + '<div class="counter-box"><div class="number">%H</div>'+$CounterHours+'</div>' + '<div class="counter-box"><div class="number">%M</div>'+$CounterMinutes+'</div>' + '<div class="counter-box last"><div class="number">%S</div>'+$CounterSeconds+'</div></div>'))
                    }); 
                });
            </script>
            <?php 
        $script = ob_get_contents();
        ob_end_clean();
        $output .= $script;
        
        return $output;
    }
}
add_shortcode( 'brando_timer', 'brando_timer' );