<?php
/**
 * The template for displaying search results pages.
 *
 * @package Brando
 */
?>
<?php
	get_template_part('templates/pages/layout');